<meta name="author" content="NMPI"/>
<meta name="copyright" content="NMPI" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="theme-color" content="#384f75" />
<link rel="apple-touch-icon" href="favicon.ico" />
<link rel="manifest" href="manifest.json" />
<link rel="icon" href="favicon.ico">
<link rel="dns-prefetch" href="//www.google.com">
<link rel="dns-prefetch" href="//www.google.co.in">
<link rel="dns-prefetch" href="//www.google-analytics.com">
<link rel="dns-prefetch" href="//www.googleadservices.com">
<link rel="dns-prefetch" href="//www.googletagmanager.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script> if('serviceWorker' in navigator) { navigator.serviceWorker.register('sw.js'); }; </script>
