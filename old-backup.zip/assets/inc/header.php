<nav  class="navbar navbar-expand-lg sticky-top navbar-light py-0">
<div class="container py-2">
<a class="navbar-brand py-2 mb-5 mb-lg-0" href="https://nationalmarketingprojects.com/">
<img src="https://nationalmarketingprojects.com/assets/img/logo.png" width="200" height="50" alt="Logo" class="img-fluid logo">
</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav ms-auto pt-5 pt-lg-0">
<li class="nav-item"> <a href="https://nationalmarketingprojects.com/" class="nav-link"> Home </a> </li>
<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Services </a>
 <ul class="dropdown-menu py-0">
  <li><a class="dropdown-item" href="digital-marketing.html">Digital Marketing</a></li>
  <li><a class="dropdown-item" href="website-design-and-development.html">Website Designing</a></li>
  <li><a class="dropdown-item" href="youtube-video-marketing.html">Video Creation & Promotion</a></li>
  <li><a class="dropdown-item" href="mobile-app-development.html">Mobile App Development</a></li>
 
  

 </ul>
</li>

<li class="nav-item"> <a href="https://nationalmarketingprojects.com/about-us.html" class="nav-link"> About Us </a></li>
<li class="nav-item"> <a href="https://nationalmarketingprojects.com/contact.html" class="nav-link"> Contact Us </a> </li>
<li class="nav-item"> <a class="nav-link nav-link" href="#">
<svg width="30" height="30">
<use xlink:href="#icon-search" fill="#c19931" />
</svg>
</a> </li>
<li class="nav-item"> <a href="#" class="nav-link nav-link text-orange">
<svg width="30" height="30">
<use xlink:href="#icon-chat" fill="#c19931" />
</svg>
Live Chat </a> </li>
</ul>
</div>
</div>
</nav>